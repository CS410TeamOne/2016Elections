<hr/>

<footer>
    <p><?php bloginfo('name'); ?></p>
</footer>

</div> <!-- /container -->

<?php
wp_footer();
